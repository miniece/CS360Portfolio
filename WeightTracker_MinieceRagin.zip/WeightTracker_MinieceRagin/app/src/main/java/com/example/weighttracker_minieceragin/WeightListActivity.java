package com.example.weighttracker_minieceragin;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Home screen. Displays every weight entry belonging to the signed-in user,
 * supports adding, editing and deleting entries, and sends the goal-reached
 * alert when a newly saved weight meets the stored goal.
 */
public class WeightListActivity extends AppCompatActivity
        implements WeightAdapter.OnEntryActionListener {

    /** Key used to pass the signed-in user's id between activities. */
    public static final String EXTRA_USER_ID = "user_id";

    private static final int SMS_PERMISSION_REQUEST = 101;

    private DatabaseHelper databaseHelper;
    private WeightAdapter adapter;

    private RecyclerView recyclerWeights;
    private TextView textEmpty;
    private TextView textGoalValue;
    private TextView textLatestValue;

    private int userId;
    private boolean smsPermissionGranted = false;

    /** Receives the result of the add and edit screens so the goal is checked only after a save. */
    private final ActivityResultLauncher<Intent> entryLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        loadEntries();
                        if (result.getResultCode() == RESULT_OK) {
                            checkGoalReached();
                        }
                    });

    /** Refreshes the summary card after the goal screen closes. */
    private final ActivityResultLauncher<Intent> goalLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> loadEntries());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_list);

        databaseHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra(EXTRA_USER_ID, DatabaseHelper.NO_RESULT);

        textGoalValue = findViewById(R.id.textGoalValue);
        textLatestValue = findViewById(R.id.textLatestValue);
        textEmpty = findViewById(R.id.textEmpty);
        recyclerWeights = findViewById(R.id.recyclerWeights);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setOnMenuItemClickListener(this::onMenuItemSelected);

        adapter = new WeightAdapter(new ArrayList<>(), this);
        recyclerWeights.setLayoutManager(new LinearLayoutManager(this));
        recyclerWeights.addItemDecoration(
                new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerWeights.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAddWeight);
        fab.setOnClickListener(v -> openEntryScreen(null));

        requestSmsPermission();
        loadEntries();
    }

    // ------------------------------------------------------------ data load

    /** Reads the user's entries and goal from the database and refreshes the screen. */
    private void loadEntries() {
        List<WeightEntry> entries = databaseHelper.getAllWeights(userId);
        adapter.setEntries(entries);

        boolean empty = entries.isEmpty();
        textEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerWeights.setVisibility(empty ? View.GONE : View.VISIBLE);

        textLatestValue.setText(empty
                ? getString(R.string.value_not_set)
                : formatPounds(entries.get(0).getWeight()));

        double goal = databaseHelper.getGoal(userId);
        textGoalValue.setText(goal == DatabaseHelper.NO_RESULT
                ? getString(R.string.value_not_set)
                : formatPounds(goal));
    }

    private String formatPounds(double value) {
        return String.format(Locale.US, "%.1f lb", value);
    }

    // --------------------------------------------------------- row actions

    @Override
    public void onEditEntry(WeightEntry entry) {
        openEntryScreen(entry);
    }

    @Override
    public void onDeleteEntry(WeightEntry entry) {
        // Deletion cannot be undone, so confirm before removing the row
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirm_delete_title)
                .setMessage(R.string.confirm_delete_message)
                .setPositiveButton(R.string.action_delete, (dialog, which) -> {
                    databaseHelper.deleteWeight(entry.getWeightId());
                    loadEntries();
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    /** Opens the entry screen, prefilled when an existing entry was tapped. */
    private void openEntryScreen(WeightEntry existingEntry) {
        Intent intent = new Intent(this, WeightEntryActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);

        if (existingEntry != null) {
            intent.putExtra(WeightEntryActivity.EXTRA_WEIGHT_ID, existingEntry.getWeightId());
            intent.putExtra(WeightEntryActivity.EXTRA_ENTRY_DATE, existingEntry.getEntryDate());
            intent.putExtra(WeightEntryActivity.EXTRA_WEIGHT_VALUE, existingEntry.getWeight());
        }
        entryLauncher.launch(intent);
    }

    private boolean onMenuItemSelected(@NonNull android.view.MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_goal) {
            Intent intent = new Intent(this, GoalActivity.class);
            intent.putExtra(EXTRA_USER_ID, userId);
            goalLauncher.launch(intent);
            return true;
        }

        if (id == R.id.action_logout) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return false;
    }

    // ------------------------------------------------- goal and SMS alerts

    /**
     * Compares the most recent entry against the stored goal and alerts the
     * user when the goal has been met.
     */
    private void checkGoalReached() {
        double goal = databaseHelper.getGoal(userId);
        List<WeightEntry> entries = databaseHelper.getAllWeights(userId);

        if (goal == DatabaseHelper.NO_RESULT || entries.isEmpty()) {
            return;
        }

        double latest = entries.get(0).getWeight();
        if (latest > goal) {
            return;
        }

        String message = getString(R.string.goal_reached, formatPounds(latest));
        String phoneNumber = databaseHelper.getPhoneNumber(userId);

        // The alert is only sent by text when permission was granted and a
        // number is on file; otherwise it is shown inside the app instead.
        if (smsPermissionGranted && !phoneNumber.isEmpty()) {
            sendSmsAlert(phoneNumber, message);
        } else if (phoneNumber.isEmpty()) {
            Toast.makeText(this, R.string.no_phone_saved, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    private void sendSmsAlert(String phoneNumber, String message) {
        try {
            SmsManager smsManager = getSystemService(SmsManager.class);
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // A failed send must not crash the app; fall back to an on-screen message
            Toast.makeText(this, R.string.sms_failed, Toast.LENGTH_LONG).show();
        }
    }

    /** Asks for SEND_SMS once; a denial disables alerts but leaves the app usable. */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            smsPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            smsPermissionGranted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            Toast.makeText(this,
                    smsPermissionGranted ? R.string.sms_granted : R.string.sms_denied,
                    Toast.LENGTH_LONG).show();
        }
    }
}