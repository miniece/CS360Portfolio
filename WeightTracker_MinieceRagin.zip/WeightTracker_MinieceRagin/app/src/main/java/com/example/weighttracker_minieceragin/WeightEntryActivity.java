package com.example.weighttracker_minieceragin;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Adds a new weight entry or edits an existing one.
 * The screen runs in edit mode when the caller supplies a weight id,
 * which keeps the Create and Update paths in a single place.
 */
public class WeightEntryActivity extends AppCompatActivity {

    public static final String EXTRA_WEIGHT_ID = "weight_id";
    public static final String EXTRA_ENTRY_DATE = "entry_date";
    public static final String EXTRA_WEIGHT_VALUE = "weight_value";

    private static final String ISO_PATTERN = "yyyy-MM-dd";
    private static final String DISPLAY_PATTERN = "MMM dd, yyyy";

    private DatabaseHelper databaseHelper;

    private TextInputLayout layoutWeight;
    private TextInputEditText editDate;
    private TextInputEditText editWeight;

    private int userId;
    private int weightId;
    private String selectedIsoDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        databaseHelper = new DatabaseHelper(this);

        userId = getIntent().getIntExtra(
                WeightListActivity.EXTRA_USER_ID, DatabaseHelper.NO_RESULT);
        weightId = getIntent().getIntExtra(EXTRA_WEIGHT_ID, DatabaseHelper.NO_RESULT);

        layoutWeight = findViewById(R.id.layoutWeight);
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);

        MaterialToolbar toolbar = findViewById(R.id.toolbarEntry);
        toolbar.setNavigationOnClickListener(v -> finish());

        // The date field opens a picker instead of accepting typed text, which
        // removes any chance of an unparseable date reaching the database
        editDate.setFocusable(false);
        editDate.setClickable(true);
        editDate.setOnClickListener(v -> showDatePicker());

        if (isEditingExistingEntry()) {
            toolbar.setTitle(R.string.title_edit_entry);
            selectedIsoDate = getIntent().getStringExtra(EXTRA_ENTRY_DATE);
            editWeight.setText(String.format(Locale.US, "%.1f",
                    getIntent().getDoubleExtra(EXTRA_WEIGHT_VALUE, 0)));
        } else {
            selectedIsoDate = todayAsIso();
        }
        showSelectedDate();

        Button save = findViewById(R.id.buttonSaveEntry);
        Button cancel = findViewById(R.id.buttonCancelEntry);

        save.setOnClickListener(v -> saveEntry());
        cancel.setOnClickListener(v -> finish());
    }

    private boolean isEditingExistingEntry() {
        return weightId != DatabaseHelper.NO_RESULT;
    }

    // ----------------------------------------------------------- date entry

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        try {
            Date parsed = new SimpleDateFormat(ISO_PATTERN, Locale.US).parse(selectedIsoDate);
            if (parsed != null) {
                calendar.setTime(parsed);
            }
        } catch (ParseException e) {
            // Fall back to today's date if the stored value cannot be read
        }

        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar chosen = Calendar.getInstance();
            chosen.set(year, month, dayOfMonth);
            selectedIsoDate = new SimpleDateFormat(ISO_PATTERN, Locale.US).format(chosen.getTime());
            showSelectedDate();
        },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    /** Shows the chosen date in a readable form while the ISO value is stored. */
    private void showSelectedDate() {
        try {
            Date parsed = new SimpleDateFormat(ISO_PATTERN, Locale.US).parse(selectedIsoDate);
            editDate.setText(parsed == null ? selectedIsoDate
                    : new SimpleDateFormat(DISPLAY_PATTERN, Locale.US).format(parsed));
        } catch (ParseException e) {
            editDate.setText(selectedIsoDate);
        }
    }

    private String todayAsIso() {
        return new SimpleDateFormat(ISO_PATTERN, Locale.US).format(Calendar.getInstance().getTime());
    }

    // ---------------------------------------------------------------- save

    /** Validates the entered weight, then writes it to the database. */
    private void saveEntry() {
        String enteredWeight = editWeight.getText() == null
                ? "" : editWeight.getText().toString().trim();

        double weight;
        try {
            weight = Double.parseDouble(enteredWeight);
        } catch (NumberFormatException e) {
            layoutWeight.setError(getString(R.string.error_invalid_weight));
            return;
        }

        if (weight <= 0) {
            layoutWeight.setError(getString(R.string.error_invalid_weight));
            return;
        }
        layoutWeight.setError(null);

        boolean saved = isEditingExistingEntry()
                ? databaseHelper.updateWeight(weightId, selectedIsoDate, weight)
                : databaseHelper.insertWeight(userId, selectedIsoDate, weight) != -1;

        if (saved) {
            // RESULT_OK tells the list screen a new value is worth checking
            // against the goal weight
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, R.string.error_invalid_weight, Toast.LENGTH_SHORT).show();
        }
    }
}