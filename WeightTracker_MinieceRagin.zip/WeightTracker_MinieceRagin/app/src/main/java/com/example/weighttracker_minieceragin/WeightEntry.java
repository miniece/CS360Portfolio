package com.example.weighttracker_minieceragin;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Model object for one row of the weights table.
 * Dates are stored in the database as yyyy-MM-dd so they sort correctly,
 * then reformatted for display.
 */
public class WeightEntry {

    private final int weightId;
    private final String entryDate;   // ISO format: yyyy-MM-dd
    private final double weight;

    public WeightEntry(int weightId, String entryDate, double weight) {
        this.weightId = weightId;
        this.entryDate = entryDate;
        this.weight = weight;
    }

    public int getWeightId() {
        return weightId;
    }

    /** Returns the raw ISO date, used when re-opening an entry for editing. */
    public String getEntryDate() {
        return entryDate;
    }

    public double getWeight() {
        return weight;
    }

    /** Converts the stored yyyy-MM-dd value into something readable, such as Oct 03, 2026. */
    public String getDisplayDate() {
        SimpleDateFormat stored = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat shown = new SimpleDateFormat("MMM dd, yyyy", Locale.US);
        try {
            Date parsed = stored.parse(entryDate);
            return parsed == null ? entryDate : shown.format(parsed);
        } catch (ParseException e) {
            // If the stored value is malformed, show it as-is rather than crashing
            return entryDate;
        }
    }
}