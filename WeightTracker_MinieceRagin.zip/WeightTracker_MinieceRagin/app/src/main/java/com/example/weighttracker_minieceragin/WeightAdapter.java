package com.example.weighttracker_minieceragin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

/**
 * Binds weight entries to the rows of the grid.
 * Tapping a row opens it for editing; tapping the trash icon deletes it.
 * Both actions are reported back to the activity, which owns the database.
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    /** Lets the hosting activity respond to row actions. */
    public interface OnEntryActionListener {
        void onEditEntry(WeightEntry entry);

        void onDeleteEntry(WeightEntry entry);
    }

    private final List<WeightEntry> entries;
    private final OnEntryActionListener actionListener;

    public WeightAdapter(List<WeightEntry> entries, OnEntryActionListener actionListener) {
        this.entries = entries;
        this.actionListener = actionListener;
    }

    /** Replaces the displayed rows after the database has changed. */
    public void setEntries(List<WeightEntry> updatedEntries) {
        entries.clear();
        entries.addAll(updatedEntries);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight, parent, false);
        return new WeightViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);

        holder.date.setText(entry.getDisplayDate());
        holder.weight.setText(String.format(Locale.US, "%.1f", entry.getWeight()));
        holder.change.setText(changeSincePreviousEntry(position));

        // Rows are ordered newest first, so tapping one reopens it for editing
        holder.itemView.setOnClickListener(v -> actionListener.onEditEntry(entry));
        holder.delete.setOnClickListener(v -> actionListener.onDeleteEntry(entry));
    }

    /**
     * Calculates the difference between this entry and the one logged before it.
     * The oldest entry has nothing to compare against, so it shows a dash.
     */
    private String changeSincePreviousEntry(int position) {
        int olderPosition = position + 1;
        if (olderPosition >= entries.size()) {
            return "--";
        }
        double difference = entries.get(position).getWeight()
                - entries.get(olderPosition).getWeight();
        return String.format(Locale.US, "%+.1f", difference);
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    /** Holds the views for one row so they are looked up only once. */
    static class WeightViewHolder extends RecyclerView.ViewHolder {

        final TextView date;
        final TextView weight;
        final TextView change;
        final ImageButton delete;

        WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.textRowDate);
            weight = itemView.findViewById(R.id.textRowWeight);
            change = itemView.findViewById(R.id.textRowChange);
            delete = itemView.findViewById(R.id.buttonDeleteRow);
        }
    }
}