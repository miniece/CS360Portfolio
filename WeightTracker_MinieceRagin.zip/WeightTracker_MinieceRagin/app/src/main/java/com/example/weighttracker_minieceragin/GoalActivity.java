package com.example.weighttracker_minieceragin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Locale;

/**
 * Stores the single goal weight for the signed-in user, along with the phone
 * number that goal alerts are sent to. Both values live in the goals table.
 */
public class GoalActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TextInputLayout layoutGoal;
    private TextInputEditText editGoal;
    private TextInputEditText editPhone;

    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        databaseHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra(
                WeightListActivity.EXTRA_USER_ID, DatabaseHelper.NO_RESULT);

        layoutGoal = findViewById(R.id.layoutGoal);
        editGoal = findViewById(R.id.editGoal);
        editPhone = findViewById(R.id.editPhone);

        MaterialToolbar toolbar = findViewById(R.id.toolbarGoal);
        toolbar.setNavigationOnClickListener(v -> finish());

        prefillExistingGoal();

        Button save = findViewById(R.id.buttonSaveGoal);
        save.setOnClickListener(v -> saveGoal());
    }

    /** Loads any goal already on file so the user edits rather than retypes. */
    private void prefillExistingGoal() {
        double existingGoal = databaseHelper.getGoal(userId);
        if (existingGoal != DatabaseHelper.NO_RESULT) {
            editGoal.setText(String.format(Locale.US, "%.1f", existingGoal));
        }
        editPhone.setText(databaseHelper.getPhoneNumber(userId));
    }

    /** Validates the goal weight, then writes the goal and phone number. */
    private void saveGoal() {
        String enteredGoal = editGoal.getText() == null
                ? "" : editGoal.getText().toString().trim();

        double goalWeight;
        try {
            goalWeight = Double.parseDouble(enteredGoal);
        } catch (NumberFormatException e) {
            layoutGoal.setError(getString(R.string.error_invalid_goal));
            return;
        }

        if (goalWeight <= 0) {
            layoutGoal.setError(getString(R.string.error_invalid_goal));
            return;
        }
        layoutGoal.setError(null);

        // The phone number is optional; without one the app shows goal alerts
        // on screen instead of sending a text message
        String phoneNumber = editPhone.getText() == null
                ? "" : editPhone.getText().toString().trim();

        if (databaseHelper.setGoal(userId, goalWeight, phoneNumber)) {
            Toast.makeText(this, R.string.goal_saved, Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        }
    }
}