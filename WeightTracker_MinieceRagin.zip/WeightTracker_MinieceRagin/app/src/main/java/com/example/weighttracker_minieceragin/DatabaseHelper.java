package com.example.weighttracker_minieceragin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Single point of access to the app's SQLite database.
 * No activity issues raw SQL directly; every read and write goes through
 * a method on this class so the schema stays in one place.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weighttracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table 1: user logins
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "user_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Table 2: daily weight entries
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_WEIGHT_ID = "weight_id";
    private static final String COL_WEIGHT_USER = "user_id";
    private static final String COL_ENTRY_DATE = "entry_date";
    private static final String COL_WEIGHT_VALUE = "weight";

    // Table 3: one goal row per user
    private static final String TABLE_GOALS = "goals";
    private static final String COL_GOAL_ID = "goal_id";
    private static final String COL_GOAL_USER = "user_id";
    private static final String COL_GOAL_VALUE = "goal_weight";
    private static final String COL_PHONE = "phone_number";

    /** Returned by lookup methods when no matching row exists. */
    public static final int NO_RESULT = -1;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_WEIGHT_USER + " INTEGER NOT NULL, "
                + COL_ENTRY_DATE + " TEXT NOT NULL, "
                + COL_WEIGHT_VALUE + " REAL NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_GOALS + " ("
                + COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_GOAL_USER + " INTEGER NOT NULL UNIQUE, "
                + COL_GOAL_VALUE + " REAL NOT NULL, "
                + COL_PHONE + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This app ships at version 1, so a simple rebuild is sufficient here.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ---------------------------------------------------------------- users

    /** True if the username is already taken, checked before creating an account. */
    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{username},
                null, null, null);
        boolean found = cursor.moveToFirst();
        cursor.close();
        return found;
    }

    /**
     * Creates a new account.
     * Passwords are stored as entered, which is acceptable for this course
     * project but would require hashing in a production application.
     *
     * @return the new user_id, or NO_RESULT if the username was taken
     */
    public int insertUser(String username, String password) {
        if (usernameExists(username)) {
            return NO_RESULT;
        }
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long newId = getWritableDatabase().insert(TABLE_USERS, null, values);
        return newId == -1 ? NO_RESULT : (int) newId;
    }

    /**
     * Checks a username and password pair against the users table.
     *
     * @return the matching user_id, or NO_RESULT if the credentials are wrong
     */
    public int validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);

        int userId = NO_RESULT;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow(COL_USER_ID));
        }
        cursor.close();
        return userId;
    }

    // -------------------------------------------------------------- weights

    /** CREATE: adds one weight entry for the given user. */
    public long insertWeight(int userId, String entryDate, double weight) {
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_USER, userId);
        values.put(COL_ENTRY_DATE, entryDate);
        values.put(COL_WEIGHT_VALUE, weight);
        return getWritableDatabase().insert(TABLE_WEIGHTS, null, values);
    }

    /** UPDATE: changes the date and value of an existing entry. */
    public boolean updateWeight(int weightId, String entryDate, double weight) {
        ContentValues values = new ContentValues();
        values.put(COL_ENTRY_DATE, entryDate);
        values.put(COL_WEIGHT_VALUE, weight);

        int rows = getWritableDatabase().update(TABLE_WEIGHTS, values,
                COL_WEIGHT_ID + " = ?", new String[]{String.valueOf(weightId)});
        return rows > 0;
    }

    /** DELETE: removes a single entry. */
    public boolean deleteWeight(int weightId) {
        int rows = getWritableDatabase().delete(TABLE_WEIGHTS,
                COL_WEIGHT_ID + " = ?", new String[]{String.valueOf(weightId)});
        return rows > 0;
    }

    /**
     * READ: every entry belonging to one user, newest first.
     * Results are scoped by user_id so two accounts on the same device
     * never see each other's data.
     */
    public List<WeightEntry> getAllWeights(int userId) {
        List<WeightEntry> entries = new ArrayList<>();

        Cursor cursor = getReadableDatabase().query(TABLE_WEIGHTS,
                new String[]{COL_WEIGHT_ID, COL_ENTRY_DATE, COL_WEIGHT_VALUE},
                COL_WEIGHT_USER + " = ?", new String[]{String.valueOf(userId)},
                null, null, COL_ENTRY_DATE + " DESC");

        while (cursor.moveToNext()) {
            entries.add(new WeightEntry(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_WEIGHT_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ENTRY_DATE)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_WEIGHT_VALUE))));
        }
        cursor.close();
        return entries;
    }

    // ---------------------------------------------------------------- goals

    /**
     * Saves the goal weight and alert phone number.
     * Each user has at most one goal row, so an existing row is updated
     * rather than duplicated.
     */
    public boolean setGoal(int userId, double goalWeight, String phoneNumber) {
        ContentValues values = new ContentValues();
        values.put(COL_GOAL_USER, userId);
        values.put(COL_GOAL_VALUE, goalWeight);
        values.put(COL_PHONE, phoneNumber);

        SQLiteDatabase db = getWritableDatabase();
        int rows = db.update(TABLE_GOALS, values,
                COL_GOAL_USER + " = ?", new String[]{String.valueOf(userId)});

        if (rows == 0) {
            return db.insert(TABLE_GOALS, null, values) != -1;
        }
        return true;
    }

    /** @return the stored goal weight, or NO_RESULT if the user has not set one */
    public double getGoal(int userId) {
        Cursor cursor = getReadableDatabase().query(TABLE_GOALS,
                new String[]{COL_GOAL_VALUE},
                COL_GOAL_USER + " = ?", new String[]{String.valueOf(userId)},
                null, null, null);

        double goal = NO_RESULT;
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_GOAL_VALUE));
        }
        cursor.close();
        return goal;
    }

    /** @return the stored alert phone number, or an empty string if none is saved */
    public String getPhoneNumber(int userId) {
        Cursor cursor = getReadableDatabase().query(TABLE_GOALS,
                new String[]{COL_PHONE},
                COL_GOAL_USER + " = ?", new String[]{String.valueOf(userId)},
                null, null, null);

        String phone = "";
        if (cursor.moveToFirst()) {
            String stored = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE));
            phone = stored == null ? "" : stored;
        }
        cursor.close();
        return phone;
    }
}