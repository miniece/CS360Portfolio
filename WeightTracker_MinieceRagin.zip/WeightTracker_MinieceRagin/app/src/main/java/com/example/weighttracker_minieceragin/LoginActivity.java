package com.example.weighttracker_minieceragin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

/**
 * Entry point of the app. The same screen handles signing in and creating a
 * first-time account, as required by the client scenario.
 */
public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TextInputEditText editUsername;
    private TextInputEditText editPassword;
    private TextView textLoginError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        textLoginError = findViewById(R.id.textLoginError);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    /** Checks the entered credentials against the users table. */
    private void attemptLogin() {
        String username = valueOf(editUsername);
        String password = valueOf(editPassword);

        if (isMissingInput(username, password)) {
            return;
        }

        int userId = databaseHelper.validateUser(username, password);
        if (userId == DatabaseHelper.NO_RESULT) {
            showError(getString(R.string.error_bad_credentials));
        } else {
            openWeightList(userId);
        }
    }

    /** Creates a new row in the users table, provided the username is free. */
    private void attemptCreateAccount() {
        String username = valueOf(editUsername);
        String password = valueOf(editPassword);

        if (isMissingInput(username, password)) {
            return;
        }

        if (databaseHelper.usernameExists(username)) {
            showError(getString(R.string.error_username_taken));
            return;
        }

        int userId = databaseHelper.insertUser(username, password);
        if (userId == DatabaseHelper.NO_RESULT) {
            showError(getString(R.string.error_account_failed));
        } else {
            openWeightList(userId);
        }
    }

    /**
     * Sends the signed-in user to the list screen and closes this activity, so
     * the Back button cannot return to a login the user has already cleared.
     */
    private void openWeightList(int userId) {
        textLoginError.setVisibility(View.GONE);

        Intent intent = new Intent(this, WeightListActivity.class);
        intent.putExtra(WeightListActivity.EXTRA_USER_ID, userId);
        startActivity(intent);
        finish();
    }

    /** True when either field is blank; also displays the matching message. */
    private boolean isMissingInput(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            showError(getString(R.string.error_empty_credentials));
            return true;
        }
        return false;
    }

    private void showError(String message) {
        textLoginError.setText(message);
        textLoginError.setVisibility(View.VISIBLE);
    }

    /** Safely reads a text field that may hold a null Editable. */
    private String valueOf(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}